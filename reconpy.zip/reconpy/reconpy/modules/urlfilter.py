import re
from reconpy.core.utils import ok, warn, read_lines, write_lines, append_unique


def run_module(out, **kwargs):
    urls_path = out.path("urls")
    urls = read_lines(urls_path)
    if not urls:
        warn("urlfilter: urls.txt is empty, skipping.")
        return

    param_urls = [u for u in urls if re.search(r"\?[^=]+=|&[^=]+=", u)]
    new_params = append_unique(out.path("parameters"), param_urls)

    ok(f"urlfilter: parameters.txt new entries: {new_params}")
