import re
import json
import tempfile
import os
from reconpy.core.utils import (
    log, ok, warn, tool_exists, run, read_lines, write_lines,
    append_unique, load_targets, wordlist_or_none, sleep_for,
)


def run_module(out, domain_input, subdomains_file=None, subs_wordlist=None, **kwargs):
    wordlist = wordlist_or_none(subs_wordlist)
    if not wordlist:
        warn("brutesubrecon: no valid subdomains wordlist provided, skipping module.")
        return

    domains = load_targets(domain_input)
    if not domains:
        warn("brutesubrecon: no valid domain input, skipping.")
        return

    subdomains_path = subdomains_file or out.path("subdomains")
    out.touch("subdomains", "subs", "cleanedsubs", "ips", "validsubs")

    log(f"brutesubrecon: total domains to process: {len(domains)}")

    all_candidates = set(read_lines(subdomains_path))

    for domain in domains:
        log(f"brutesubrecon: starting bruteforce for {domain}")

        ffuf_hosts = []
        if tool_exists("ffuf"):
            log(f"brutesubrecon: ffuf on {domain}...")
            with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
                tmp_path = tmp.name
            run([
                "ffuf", "-u", f"https://FUZZ.{domain}",
                "-w", wordlist, "-t", "1", "-rate", "5", "-timeout", "10",
                "-mc", "200,301,302,403", "-o", tmp_path, "-of", "json", "-s",
            ], timeout=600)
            if os.path.isfile(tmp_path):
                try:
                    with open(tmp_path) as f:
                        data = json.load(f)
                    for r in data.get("results", []):
                        host = r.get("input", {}).get("FUZZ", "")
                        if host:
                            ffuf_hosts.append(f"{host}.{domain}")
                except Exception:
                    pass
                os.remove(tmp_path)
            sleep_for(5)
        else:
            warn("ffuf not found, skipping ffuf step.")

        knock_hosts = []
        if tool_exists("knockpy"):
            log(f"brutesubrecon: knockpy on {domain}...")
            out_text = run(["knockpy", domain, "--recon", "--no-http"], timeout=300)
            knock_hosts = re.findall(rf"[a-zA-Z0-9._-]+\.{re.escape(domain)}", out_text)
            sleep_for(5)
        else:
            warn("knockpy not found, skipping.")

        alterx_hosts = []
        if tool_exists("alterx"):
            domain_subs = [s for s in all_candidates if domain in s]
            if domain_subs:
                log(f"brutesubrecon: alterx permutation on {domain}...")
                input_text = "\n".join(domain_subs)
                out_text = run(["alterx", "-enrich"], timeout=120, input_text=input_text)
                alterx_hosts = [l.strip() for l in out_text.splitlines() if l.strip()]
                sleep_for(3)
        else:
            warn("alterx not found, skipping.")

        domain_pattern = re.compile(
            r"^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$"
        )
        for host in ffuf_hosts + knock_hosts + alterx_hosts:
            host = host.strip().lower()
            if host and domain_pattern.match(host) and domain in host:
                all_candidates.add(host)

    all_candidates = sorted(all_candidates)
    ok(f"brutesubrecon: total unique candidates: {len(all_candidates)}")

    resolved = []
    if tool_exists("dnsx") and all_candidates:
        log("brutesubrecon: resolving with dnsx...")
        input_text = "\n".join(all_candidates)
        out_text = run(["dnsx", "-t", "1", "-rl", "5", "-silent"], timeout=300, input_text=input_text)
        resolved = [l.strip() for l in out_text.splitlines() if l.strip()]
    else:
        warn("dnsx not found or no candidates.")

    dnsx_map = {}
    ipv4_pat = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")
    if tool_exists("dnsx") and resolved:
        log("brutesubrecon: running dnsx for IP/hostname info...")
        input_text = "\n".join(resolved)
        out_text = run(["dnsx", "-t", "1", "-rl", "5", "-a", "-resp", "-silent"], timeout=300, input_text=input_text)
        for line in out_text.splitlines():
            parts = line.split()
            if not parts:
                continue
            sub = parts[0]
            brackets = re.findall(r"\[([^\]]+)\]", line)
            ip = "0.0.0.0"
            for val in brackets:
                if ipv4_pat.match(val):
                    ip = val
                    break
            dnsx_map[sub] = ip

    httpx_map = {}
    if tool_exists("httpx") and resolved:
        log("brutesubrecon: checking status codes with httpx...")
        input_text = "\n".join(resolved)
        out_text = run(["httpx", "-t", "1", "-rate-limit", "5", "-timeout", "10", "-status-code", "-silent"],
                        timeout=300, input_text=input_text)
        for line in out_text.splitlines():
            parts = line.split()
            if len(parts) >= 2:
                url = parts[0].replace("https://", "").replace("http://", "").rstrip("/")
                code = parts[1].strip("[]")
                httpx_map[url] = code

    subs_lines, cleaned_lines, valid_lines = [], [], []
    all_ips = set()

    for sub in resolved:
        code = httpx_map.get(sub, "N/A")
        ip = dnsx_map.get(sub, "0.0.0.0")
        status_text = "OK" if code == "200" else code
        subs_lines.append(f"{sub} {code} {status_text} {ip} {sub}")
        cleaned_lines.append(sub)
        if ip != "0.0.0.0":
            all_ips.add(ip)
        if code == "200":
            valid_lines.append(sub)

    write_lines(out.path("subs"), subs_lines, append=True)
    new_subs = append_unique(subdomains_path, cleaned_lines)
    append_unique(out.path("cleanedsubs"), cleaned_lines)
    append_unique(out.path("validsubs"), valid_lines)
    new_ips = append_unique(out.path("ips"), all_ips)

    ok(f"{new_subs} new subdomains added to {subdomains_path}")
    ok(f"ips.txt new unique IPs: {new_ips}")
