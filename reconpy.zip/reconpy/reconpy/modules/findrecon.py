import re
from reconpy.core.utils import (
    log, ok, warn, tool_exists, run, write_lines, read_lines,
    append_unique, load_targets, to_url, domain_of, sleep_for,
)

URL_PAT = re.compile(r"https?://[^\s]+")


def run_module(out, domain_input, subdomains_file=None, **kwargs):
    targets = []
    subs = read_lines(subdomains_file) if subdomains_file else []
    if subs:
        targets = [to_url(s) for s in subs]
    else:
        domains = load_targets(domain_input)
        targets = [to_url(d) for d in domains]

    targets = sorted(set(targets))
    if not targets:
        warn("findrecon: no targets available, skipping.")
        return

    ok(f"findrecon: total targets: {len(targets)}")

    raw_all = []
    secrets_lines = []
    karma_lines = []

    for target in targets:
        domain = domain_of(target)
        log(f"findrecon: processing {target}...")

        if tool_exists("assetfinder"):
            out_text = run(["assetfinder", "--subs-only", domain], timeout=120)
            for line in out_text.splitlines():
                line = line.strip()
                if line:
                    raw_all.append(to_url(line))
            sleep_for(5)
        else:
            warn("assetfinder not found, skipping.")

        if tool_exists("linkfinder"):
            out_text = run(["linkfinder", "-i", target, "-d", "-o", "cli"], timeout=120)
            raw_all.extend(URL_PAT.findall(out_text))
            sleep_for(5)
        else:
            warn("linkfinder not found, skipping.")

        if tool_exists("secretfinder"):
            out_text = run(["secretfinder", "-i", target, "-e", "-o", "cli"], timeout=120)
            raw_all.extend(URL_PAT.findall(out_text))
            sleep_for(5)
        else:
            warn("secretfinder not found, skipping.")

        if tool_exists("xnLinkFinder"):
            out_text = run(["xnLinkFinder", "-i", target, "-d", domain, "-o", "cli"], timeout=120)
            raw_all.extend(URL_PAT.findall(out_text))
            sleep_for(5)
        else:
            warn("xnLinkFinder not found, skipping.")

        if tool_exists("urlfinder"):
            out_text = run(["urlfinder", "-d", domain, "-all", "-silent"], timeout=120)
            raw_all.extend(URL_PAT.findall(out_text))
            sleep_for(5)
        else:
            warn("urlfinder not found, skipping.")

        if tool_exists("paramspider"):
            out_text = run(["paramspider", "-d", domain, "--quiet"], timeout=120)
            raw_all.extend(URL_PAT.findall(out_text))
            sleep_for(5)
        else:
            warn("paramspider not found, skipping.")

        if tool_exists("crlfuzz"):
            out_text = run(["crlfuzz", "-u", target, "-s"], timeout=120)
            raw_all.extend(URL_PAT.findall(out_text))
            sleep_for(5)
        else:
            warn("crlfuzz not found, skipping.")

        if tool_exists("mantra"):
            out_text = run(["mantra", "-s"], timeout=120, input_text=target + "\n")
            if out_text.strip():
                secrets_lines.append(f"[Mantra] {target}")
                secrets_lines.append(out_text.strip())
                secrets_lines.append("")
            sleep_for(5)
        else:
            warn("mantra not found, skipping.")

        if tool_exists("karma_v2"):
            out_text = run(["karma_v2", "-d", domain, "-l", "50", "-leaks", "-s"], timeout=180)
            if out_text.strip():
                karma_lines.append(f"[Karma-Leaks] {domain}")
                karma_lines.append(out_text.strip())
                karma_lines.append("")
            sleep_for(5)
        elif tool_exists("karma"):
            out_text = run(["karma", "-d", domain, "-l", "50", "-leaks", "-s"], timeout=180)
            if out_text.strip():
                karma_lines.append(f"[Karma-Leaks] {domain}")
                karma_lines.append(out_text.strip())
                karma_lines.append("")
            sleep_for(5)
        else:
            warn("karma_v2 not found, skipping.")

        if tool_exists("smap"):
            out_text = run(["smap", domain], timeout=120)
            if out_text.strip():
                karma_lines.append(f"[Smap] {domain}")
                karma_lines.append(out_text.strip())
                karma_lines.append("")
            sleep_for(8)
        else:
            warn("smap not found, skipping.")

    unique_urls = sorted(set(raw_all))
    new_find = append_unique(out.path("findurls"), unique_urls)
    new_urls = append_unique(out.path("urls"), unique_urls)

    if secrets_lines:
        with open(out.path("secretsreport"), "a") as f:
            for line in secrets_lines:
                f.write(line + "\n")

    if karma_lines:
        with open(out.path("karmareport"), "a") as f:
            for line in karma_lines:
                f.write(line + "\n")

    ok(f"findurls.txt new entries: {new_find}")
    ok(f"urls.txt new entries: {new_urls}")
    ok(f"secretsreport.txt entries this run: {len([l for l in secrets_lines if l.startswith('[Mantra]')])}")
    ok(f"karmareport.txt entries this run: {len([l for l in karma_lines if l.startswith('[Karma') or l.startswith('[Smap')])}")
