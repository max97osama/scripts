import re
from reconpy.core.utils import log, ok, warn, tool_exists, run, read_lines

VULN_KEYWORDS = [
    "VULNERABLE", "CVE-", "State: VULNERABLE", "State: LIKELY VULNERABLE",
    "exploitable", "Exploit", "exploit", "Risk factor", "HIGH", "CRITICAL",
    "disclosure", "injection", "overflow", "bypass", "traversal", "RCE",
    "remote code", "XSS", "SQL", "SSRF", "LFI", "RFI", "open redirect",
    "misconfiguration", "weak", "brute", "default credentials", "anonymous",
    "cleartext", "unencrypted", "backdoor",
]


def scan_ip(ip):
    out_text = run([
        "nmap", "-sV", "-sC", "--script", "vuln", "-p-", "-T2",
        "--min-rate", "100", "--max-rate", "300", "--max-retries", "2",
        "--host-timeout", "60m", ip,
    ], timeout=3600)
    return out_text


def filter_vuln_output(content):
    blocks = re.split(r"\n(?=\d+/)", content)
    findings = []
    for block in blocks:
        block_lower = block.lower()
        matched = [kw for kw in VULN_KEYWORDS if kw.lower() in block_lower]
        if matched:
            findings.append(block.strip())
            findings.append(f"[!] Triggered keywords: {', '.join(set(matched))}")
            findings.append("-" * 64)

    script_sections = re.findall(r"(\|\s*\w[\w\-]+:.*?)(?=\n\d+/|\Z)", content, re.DOTALL)
    for section in script_sections:
        matched = [kw for kw in VULN_KEYWORDS if kw.lower() in section.lower()]
        if matched:
            findings.append(section.strip())
            findings.append(f"[!] Triggered keywords: {', '.join(set(matched))}")
            findings.append("-" * 64)

    return findings


def run_module(out, ips_file=None, **kwargs):
    if not tool_exists("nmap"):
        warn("nmapscan: nmap not found, skipping module.")
        return

    ips_path = ips_file or out.path("ips")
    ips = read_lines(ips_path)
    if not ips:
        warn("nmapscan: no IPs found, skipping.")
        return

    ok(f"nmapscan: total IPs to scan: {len(ips)}")

    all_findings = []
    for ip in ips:
        log(f"nmapscan: scanning {ip}...")
        raw = scan_ip(ip)
        findings = filter_vuln_output(raw)
        all_findings.append(f"=" * 64)
        all_findings.append(f"NMAP VULNERABILITY REPORT FOR: {ip}")
        all_findings.append("=" * 64)
        if findings:
            all_findings.extend(findings)
        else:
            all_findings.append("[*] No vulnerabilities detected by nmap scripts on this target.")
        all_findings.append("")

    with open(out.path("nmapreport"), "a") as f:
        for line in all_findings:
            f.write(line + "\n")

    ok(f"nmapreport.txt updated, total lines this run: {len(all_findings)}")
