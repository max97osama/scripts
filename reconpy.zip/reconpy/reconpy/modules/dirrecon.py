import re
import json
import tempfile
import os
from reconpy.core.utils import (
    log, ok, warn, tool_exists, run, read_lines, write_lines,
    load_targets, to_url, wordlist_or_none, sleep_for,
)


def run_module(out, domain_input, subdomains_file=None, dir_wordlist=None, **kwargs):
    wordlist = wordlist_or_none(dir_wordlist)
    if not wordlist:
        warn("dirrecon: no valid directory wordlist provided, skipping module.")
        return

    subs_path = subdomains_file or out.path("subdomains")
    subs = read_lines(subs_path)

    targets = set()
    if domain_input:
        targets.add(to_url(domain_input if not os.path.isfile(domain_input) else ""))
    for s in subs:
        targets.add(to_url(s))
    targets.discard("https://")
    targets = sorted(targets)

    if not targets:
        warn("dirrecon: no targets available, skipping.")
        return

    ok(f"dirrecon: total targets: {len(targets)}")

    results = []

    for target in targets:
        log(f"dirrecon: scanning {target}...")

        if tool_exists("ffuf"):
            log(f"dirrecon: ffuf on {target}...")
            with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
                tmp_path = tmp.name
            run([
                "ffuf", "-u", f"{target}/FUZZ", "-w", wordlist, "-t", "1", "-rate", "3",
                "-timeout", "15", "-mc", "200,201,204,301,302,307,401,403",
                "-o", tmp_path, "-of", "json", "-s",
            ], timeout=900)
            if os.path.isfile(tmp_path):
                try:
                    with open(tmp_path) as f:
                        data = json.load(f)
                    for r in data.get("results", []):
                        url = r.get("url", "")
                        status = r.get("status", "")
                        if url:
                            results.append(f"{url} [{status}]")
                except Exception:
                    pass
                os.remove(tmp_path)
            sleep_for(10)
        else:
            warn("ffuf not found, skipping ffuf step.")

        if tool_exists("dirsearch"):
            log(f"dirrecon: dirsearch on {target}...")
            with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as tmp:
                tmp_path = tmp.name
            run([
                "dirsearch", "-u", target, "-w", wordlist, "-t", "1", "--delay=2",
                "--timeout=15", "-e", "php,html,js,txt,json,xml,bak,old,zip",
                f"--plain-text-report={tmp_path}", "-q",
            ], timeout=900)
            if os.path.isfile(tmp_path):
                for line in read_lines(tmp_path):
                    if line.startswith("["):
                        results.append(f"{target} {line}")
                os.remove(tmp_path)
            sleep_for(10)
        else:
            warn("dirsearch not found, skipping.")

        if tool_exists("gobuster"):
            log(f"dirrecon: gobuster on {target}...")
            with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as tmp:
                tmp_path = tmp.name
            run([
                "gobuster", "dir", "-u", target, "-w", wordlist, "-t", "1",
                "--delay", "2000ms", "--timeout", "15s", "-q", "-o", tmp_path,
            ], timeout=900)
            if os.path.isfile(tmp_path):
                for line in read_lines(tmp_path):
                    results.append(f"{target} {line}")
                os.remove(tmp_path)
            sleep_for(15)
        else:
            warn("gobuster not found, skipping.")

    unique_results = sorted(set(results))
    write_lines(out.path("burl"), unique_results, append=True)
    ok(f"dirrecon: total found URLs this run: {len(unique_results)}")

    if unique_results:
        added = 0
        existing = set(read_lines(out.path("urls")))
        new_ones = set(unique_results) - existing
        if new_ones:
            write_lines(out.path("urls"), sorted(new_ones), append=True)
            added = len(new_ones)
        ok(f"burl.txt appended to urls.txt, new lines: {added}")
