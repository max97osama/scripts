import re
from reconpy.core.utils import log, ok, warn, tool_exists, run, read_lines, write_lines

URL_EXTRACT_PAT = re.compile(
    r"(https?://[a-zA-Z0-9./_:@?=&%+~#-]+|www\.[a-zA-Z0-9./_:@?=&%+~#-]+"
    r"|[a-zA-Z0-9][a-zA-Z0-9._-]*\.[a-zA-Z]{2,}(?:/[a-zA-Z0-9./_:@?=&%+~#-]*)?)"
)
IMG_EXT_PAT = re.compile(
    r"\.(jpg|jpeg|png|gif|svg|ico|bmp|webp|woff|woff2|ttf|eot|pdf|mp4|mp3)$", re.IGNORECASE
)


def run_module(out, **kwargs):
    urls_path = out.path("urls")
    raw_lines = read_lines(urls_path)
    if not raw_lines:
        warn("cleanurls: urls.txt is empty, skipping.")
        return

    extracted = []
    for line in raw_lines:
        matches = URL_EXTRACT_PAT.findall(line) if isinstance(URL_EXTRACT_PAT.findall(line), list) else []
        found = URL_EXTRACT_PAT.finditer(line)
        for m in found:
            token = m.group(0)
            if token:
                extracted.append(token)

    cleaned = []
    for token in extracted:
        token = token.strip()
        if not token or token.isdigit():
            continue
        if IMG_EXT_PAT.search(token):
            continue
        if "." not in token:
            continue
        cleaned.append(token)

    unique = sorted(set(cleaned))

    if tool_exists("uro"):
        log("cleanurls: running uro for deep deduplication...")
        import tempfile
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as tmp_in:
            tmp_in.write("\n".join(unique))
            tmp_in_path = tmp_in.name
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as tmp_out:
            tmp_out_path = tmp_out.name

        run(["uro", "-i", tmp_in_path, "-o", tmp_out_path], timeout=120)

        result_lines = read_lines(tmp_out_path)
        if result_lines:
            unique = sorted(set(result_lines))

        import os
        os.remove(tmp_in_path)
        os.remove(tmp_out_path)
    else:
        warn("uro not found, skipping deep deduplication.")

    write_lines(urls_path, unique, append=False)
    ok(f"cleanurls: clean unique URLs in urls.txt: {len(unique)}")
