import re
from reconpy.core.utils import (
    log, ok, warn, tool_exists, run, read_lines, write_lines,
    append_unique, load_targets, belongs_to_domain, sleep_for,
)
from reconpy.core.config import setup_haktrails


def run_module(out, domain_input, subdomains_file=None, **kwargs):
    domains = load_targets(domain_input)
    if not domains:
        warn("passivesubrecon: no valid domain input, skipping.")
        return

    log(f"passivesubrecon: total domains to process: {len(domains)}")

    subdomains_path = subdomains_file or out.path("subdomains")
    out.touch("subdomains", "subs", "cleanedsubs", "ips", "ipsv6", "validsubs")

    setup_haktrails()

    amass_raw, amass_ips_raw, subfinder_raw, sublist3r_raw, haktrails_raw = [], [], [], [], []

    for d in domains:
        log(f"passivesubrecon: starting for {d}")

        if tool_exists("amass"):
            log(f"passivesubrecon: amass passive (hostnames) on {d}...")
            out_text = run(["amass", "enum", "-passive", "-d", d], timeout=180)
            amass_raw.extend(out_text.splitlines())
            sleep_for(3)

            log(f"passivesubrecon: amass passive (with IPs) on {d}...")
            out_text = run(["amass", "enum", "-passive", "-d", d, "-ip"], timeout=180)
            amass_ips_raw.extend(out_text.splitlines())
            sleep_for(5)
        else:
            warn("amass not found, skipping amass steps.")

        if tool_exists("subfinder"):
            log(f"passivesubrecon: subfinder on {d}...")
            out_text = run(["subfinder", "-d", d, "-t", "1", "-timeout", "30", "-silent"], timeout=120)
            subfinder_raw.extend(out_text.splitlines())
            sleep_for(5)
        else:
            warn("subfinder not found, skipping.")

        if tool_exists("sublist3r"):
            log(f"passivesubrecon: sublist3r on {d}...")
            out_text = run(["sublist3r", "-d", d], timeout=180)
            sublist3r_raw.extend(out_text.splitlines())
            sleep_for(5)
        else:
            warn("sublist3r not found, skipping.")

        if tool_exists("haktrails"):
            log(f"passivesubrecon: haktrails subdomains on {d}...")
            out_text = run("haktrails subdomains", timeout=60, input_text=d + "\n")
            haktrails_raw.extend(out_text.splitlines())
            sleep_for(5)
        else:
            warn("haktrails not found, skipping.")

    ok(f"amass hostnames found: {len(amass_raw)}")
    ok(f"subfinder hostnames found: {len(subfinder_raw)}")
    ok(f"sublist3r hostnames found: {len(sublist3r_raw)}")
    ok(f"haktrails hostnames found: {len(haktrails_raw)}")

    ipv4_pat = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")
    all_ips_from_amass = set()
    for line in amass_ips_raw:
        for tok in re.findall(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}", line):
            all_ips_from_amass.add(tok)

    found_hosts = set()
    all_raw = amass_raw + amass_ips_raw + subfinder_raw + sublist3r_raw + haktrails_raw
    for line in all_raw:
        line = line.strip()
        if not line:
            continue
        for tok in re.split(r"[\s,]+", line):
            tok = tok.strip().rstrip(".")
            if not tok:
                continue
            if re.match(r"^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)+$", tok):
                if belongs_to_domain(tok.lower(), domains):
                    found_hosts.add(tok.lower())

    existing_subs = set(read_lines(subdomains_path))
    all_candidates = sorted(found_hosts | existing_subs)
    ok(f"total unique candidates before resolution: {len(all_candidates)}")

    dnsx_map = {}
    if tool_exists("dnsx") and all_candidates:
        log("passivesubrecon: resolving with dnsx...")
        input_text = "\n".join(all_candidates)
        dnsx_out = run(
            ["dnsx", "-t", "1", "-rl", "5", "-a", "-aaaa", "-resp", "-silent"],
            timeout=300, input_text=input_text,
        )
        for line in dnsx_out.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if not parts:
                continue
            sub = parts[0]
            brackets = re.findall(r"\[([^\]]+)\]", line)
            ip = "0.0.0.0"
            for val in brackets:
                if ipv4_pat.match(val):
                    ip = val
                    break
            dnsx_map[sub] = ip
    else:
        warn("dnsx not found or no candidates, skipping resolution.")

    resolved_hosts = list(dnsx_map.keys()) if dnsx_map else all_candidates

    httpx_map = {}
    if tool_exists("httpx") and resolved_hosts:
        log("passivesubrecon: checking alive status with httpx...")
        input_text = "\n".join(resolved_hosts)
        httpx_out = run(
            ["httpx", "-t", "1", "-rate-limit", "5", "-timeout", "10", "-status-code", "-silent"],
            timeout=300, input_text=input_text,
        )
        for line in httpx_out.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) >= 2:
                url = parts[0].replace("https://", "").replace("http://", "").rstrip("/")
                code = parts[1].strip("[]")
                httpx_map[url] = code
    else:
        warn("httpx not found or no hosts to check.")

    all_v4, all_v6 = set(all_ips_from_amass), set()
    subs_lines, cleaned_lines, valid_lines = [], [], []

    for sub in resolved_hosts:
        code = httpx_map.get(sub, "N/A")
        ip = dnsx_map.get(sub, "0.0.0.0")
        status_text = "OK" if code == "200" else code
        subs_lines.append(f"{sub} {code} {status_text} {ip} {sub}")
        cleaned_lines.append(sub)
        if ip != "0.0.0.0":
            if ":" in ip:
                all_v6.add(ip)
            else:
                all_v4.add(ip)
        if code == "200":
            valid_lines.append(sub)

    write_lines(out.path("subs"), subs_lines, append=True)
    new_subs = append_unique(subdomains_path, cleaned_lines)
    append_unique(out.path("cleanedsubs"), cleaned_lines)
    append_unique(out.path("validsubs"), valid_lines)
    new_ips = append_unique(out.path("ips"), all_v4)
    append_unique(out.path("ipsv6"), all_v6)

    ok(f"{new_subs} new subdomains added to {subdomains_path}")
    ok(f"validsubs.txt 200 OK entries this run: {len(valid_lines)}")
    ok(f"ips.txt new unique IPv4: {new_ips}")
    ok(f"ipsv6.txt total unique IPv6: {len(all_v6)}")
