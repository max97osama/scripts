import re
from reconpy.core.utils import (
    log, ok, warn, tool_exists, run, read_lines, write_lines,
    load_targets, to_url, domain_of, wordlist_or_none, sleep_for,
)

URL_PAT = re.compile(r"https?://[^\s]+")

REDIRECT_PAYLOADS = [
    "//evil.com",
    "https://evil.com",
    "//google.com%252F@evil.com",
    "https:evil.com",
    "/\\evil.com",
    "////evil.com",
]


def run_module(out, domain_input, subdomains_file=None, kite_wordlist=None, **kwargs):
    kite = wordlist_or_none(kite_wordlist)
    if not kite:
        warn("apirecon: no valid kite wordlist provided, skipping module.")
        return

    domains = load_targets(domain_input)
    domain = domains[0] if domains else ""

    subs = read_lines(subdomains_file) if subdomains_file else []
    targets = sorted(set([to_url(s) for s in subs] + ([to_url(domain)] if domain else [])))

    if not targets:
        warn("apirecon: no targets available, skipping.")
        return

    report_lines = []
    vuln_urls = []

    def log_section(title):
        report_lines.append("=" * 64)
        report_lines.append(title)
        report_lines.append("=" * 64)

    log_section(f"RECON REPORT FOR: {domain}")

    if tool_exists("assetfinder") and domain:
        log("apirecon: assetfinder...")
        out_text = run(["assetfinder", "--subs-only", domain], timeout=120)
        report_lines.append(out_text)
        ok(f"assetfinder found {len(out_text.splitlines())} assets")
        sleep_for(5)

    if tool_exists("kr"):
        log_section("KITERUNNER")
        for target in targets:
            log(f"apirecon: kiterunner scanning {target}...")
            out_text = run(["kr", "scan", target, "-w", kite, "--delay", "500ms",
                             "--parallelism", "1", "--timeout", "10s", "-o", "text"], timeout=600)
            report_lines.append(out_text)
            for line in out_text.splitlines():
                if re.search(r"GET|POST|PUT|DELETE", line) and "404" not in line and "Not Found" not in line:
                    parts = line.split()
                    if parts:
                        vuln_urls.append(parts[-1])
            sleep_for(8)
    else:
        warn("kr (kiterunner) not found, skipping kiterunner step.")

    arjun_all = []
    if tool_exists("arjun"):
        log_section("ARJUN - PARAMETER DISCOVERY")
        for target in targets:
            log(f"apirecon: arjun scanning {target}...")
            out_text = run(["arjun", "-u", target, "-t", "1", "--delay", "3", "--passive"], timeout=180)
            report_lines.append(out_text)
            arjun_all.extend(URL_PAT.findall(out_text))
            sleep_for(8)
    else:
        warn("arjun not found, skipping.")

    linkfinder_out = []
    if tool_exists("linkfinder"):
        log_section("LINKFINDER")
        for target in targets:
            out_text = run(["linkfinder", "-i", target, "-d", "-o", "cli"], timeout=120)
            report_lines.append(out_text)
            linkfinder_out.extend(out_text.splitlines())
            sleep_for(8)
        for line in linkfinder_out:
            if re.search(r"admin|api|upload|config|backup|debug|test|dev|secret|key|token|login|auth|passwd|password|\.env|\.git|\.sql|\.bak", line, re.IGNORECASE):
                vuln_urls.append(line.strip())
    else:
        warn("linkfinder not found, skipping.")

    secretfinder_out = []
    if tool_exists("secretfinder"):
        log_section("SECRETFINDER")
        for target in targets:
            out_text = run(["secretfinder", "-i", target, "-e", "-o", "cli"], timeout=120)
            report_lines.append(out_text)
            secretfinder_out.extend(out_text.splitlines())
            sleep_for(8)
        for line in secretfinder_out:
            if re.search(r"api_key|secret|token|password|aws|private|auth|bearer|jwt", line, re.IGNORECASE):
                vuln_urls.append(line.strip())
    else:
        warn("secretfinder not found, skipping.")

    param_urls = sorted(set(u for u in arjun_all if u))
    if tool_exists("qsreplace") and param_urls:
        log_section("QSREPLACE - PARAMETER INJECTION TEST")
        input_text = "\n".join(param_urls)
        fuzzed = run(["qsreplace", "FUZZ"], timeout=60, input_text=input_text)
        fuzzed_urls = sorted(set(l.strip() for l in fuzzed.splitlines() if l.strip()))
        report_lines.extend(fuzzed_urls)
        for url in fuzzed_urls:
            status_out = run(["curl", "-sk", "-o", "/dev/null", "-w", "%{http_code}",
                               "--max-time", "10", "--connect-timeout", "5", "-A", "Mozilla/5.0", url], timeout=15)
            if status_out.strip() in ("200", "301", "302", "403", "500"):
                vuln_urls.append(f"{url} [{status_out.strip()}]")
            sleep_for(3)
    else:
        warn("qsreplace not found or no param URLs, skipping.")

    if tool_exists("oralyzer") and param_urls:
        log_section("ORALYZER - OPEN REDIRECT CHECK")
        input_text = "\n".join(param_urls)
        out_text = run(["oralyzer"], timeout=180, input_text=input_text)
        report_lines.append(out_text)
        for line in out_text.splitlines():
            if re.search(r"vulnerable|redirect|open redirect", line, re.IGNORECASE):
                vuln_urls.append(line.strip())
    else:
        warn("oralyzer not found or no param URLs, skipping.")

    if tool_exists("openredirex") and param_urls:
        log_section("OPENREDIREX - OPEN REDIRECT FUZZING")
        redirect_urls = [u for u in param_urls if re.search(
            r"url=|redirect=|return=|next=|dest=|target=|rurl=|redir=|continue=", u, re.IGNORECASE)]
        redirect_urls = [re.sub(
            r"(url=|redirect=|return=|next=|dest=|target=|rurl=|redir=|continue=)[^&]*",
            r"\1FUZZ", u, flags=re.IGNORECASE) for u in redirect_urls]

        if redirect_urls:
            import tempfile
            with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as tmp:
                tmp.write("\n".join(REDIRECT_PAYLOADS))
                payload_path = tmp.name

            for target_url in redirect_urls:
                out_text = run(["openredirex", "-p", payload_path, "-k", "FUZZ", "-c", "20"],
                                timeout=60, input_text=target_url + "\n")
                report_lines.append(out_text)
                for line in out_text.splitlines():
                    if re.search(r"vulnerable|redirect", line, re.IGNORECASE):
                        vuln_urls.append(line.strip())
                sleep_for(2)

            import os
            os.remove(payload_path)
    else:
        warn("openredirex not found or no redirect params, skipping.")

    unique_vulns = sorted(set(v for v in vuln_urls if v))

    with open(out.path("report"), "a") as f:
        for line in report_lines:
            f.write(str(line) + "\n")

    from reconpy.core.utils import append_unique
    new_vuln = append_unique(out.path("vulnerable_urls"), unique_vulns)
    new_urls = append_unique(out.path("urls"), unique_vulns)

    ok(f"apirecon: vulnerable_urls.txt new entries: {new_vuln}")
    ok(f"apirecon: urls.txt new entries: {new_urls}")
    ok(f"apirecon: report.txt updated")
