import re
from reconpy.core.utils import log, ok, warn, tool_exists, run, read_lines, wordlist_or_none, sleep_for


def run_module(out, parameters_file=None, xss_wordlist=None, **kwargs):
    params_path = parameters_file or out.path("parameters")
    urls = read_lines(params_path)
    if not urls:
        warn("xssrecon: no URLs found in parameters.txt, skipping.")
        return

    payloads_file = wordlist_or_none(xss_wordlist)
    if payloads_file:
        ok(f"xssrecon: using custom payload list: {payloads_file}")
        first_payload = read_lines(payloads_file)[0] if read_lines(payloads_file) else ""
    else:
        log("xssrecon: no payload list provided, using tool defaults.")
        first_payload = ""

    ok(f"xssrecon: total URLs to test: {len(urls)}")

    report_lines = []

    for url in urls:
        log(f"xssrecon: testing {url}...")

        if tool_exists("dalfox"):
            cmd = ["dalfox", "url", url, "--silence", "--no-color", "--skip-bav"]
            if payloads_file:
                cmd += ["--custom-payload", payloads_file, "--only-custom-payload"]
            out_text = run(cmd, timeout=120)
            for line in out_text.splitlines():
                if line.startswith("[POC]"):
                    report_lines.append(f"[Dalfox] {url}")
                    report_lines.append(line)
                    report_lines.append("")
        else:
            warn("dalfox not found, skipping.")

        if tool_exists("xsstrike"):
            cmd = ["xsstrike", "-u", url, "--skip-dom", "--console-log-level", "0"]
            if payloads_file:
                cmd += ["--payload-list", payloads_file]
            out_text = run(cmd, timeout=120)
            if re.search(r"Vulnerable webpage", out_text, re.IGNORECASE):
                report_lines.append(f"[XSStrike] {url}")
                for line in out_text.splitlines():
                    if re.search(r"Payload|Vulnerable webpage|Efficiency|Confidence", line, re.IGNORECASE):
                        report_lines.append(line.strip())
                report_lines.append("")
        else:
            warn("xsstrike not found, skipping.")

        if tool_exists("loxs"):
            out_text = run(["loxs", "-u", url], timeout=120)
            if re.search(r"vulnerable", out_text, re.IGNORECASE):
                report_lines.append(f"[Loxs] {url}")
                for line in out_text.splitlines():
                    if re.search(r"vulnerable|payload", line, re.IGNORECASE):
                        report_lines.append(line.strip())
                report_lines.append("")
        else:
            warn("loxs not found, skipping.")

        if tool_exists("pwnxss"):
            cmd = ["pwnxss", "-u", url, "--single"]
            if first_payload:
                cmd += ["--payload", first_payload]
            out_text = run(cmd, timeout=120)
            if re.search(r"vulnerable", out_text, re.IGNORECASE):
                report_lines.append(f"[PwnXSS] {url}")
                for line in out_text.splitlines():
                    if re.search(r"vulnerable|payload|xss found", line, re.IGNORECASE):
                        report_lines.append(line.strip())
                report_lines.append("")
        else:
            warn("pwnxss not found, skipping.")

        if tool_exists("xspear"):
            out_text = run(["xspear", "-u", url, "-a", "-v", "0"], timeout=120)
            if re.search(r"vulnerable", out_text, re.IGNORECASE):
                report_lines.append(f"[XSpear] {url}")
                for line in out_text.splitlines():
                    if re.search(r"vulnerable|payload", line, re.IGNORECASE):
                        report_lines.append(line.strip())
                report_lines.append("")
        else:
            warn("xspear not found, skipping.")

        if tool_exists("xssfinder"):
            cmd = ["xssfinder", "-u", url]
            if first_payload:
                cmd += ["-p", first_payload]
            out_text = run(cmd, timeout=120)
            if re.search(r"vulnerable", out_text, re.IGNORECASE):
                report_lines.append(f"[XSSFinder] {url}")
                for line in out_text.splitlines():
                    if re.search(r"vulnerable|payload", line, re.IGNORECASE):
                        report_lines.append(line.strip())
                report_lines.append("")
        else:
            warn("xssfinder not found, skipping.")

        if tool_exists("xss-automation"):
            out_text = run(["xss-automation", "-u", url], timeout=120)
            if re.search(r"vulnerable", out_text, re.IGNORECASE):
                report_lines.append(f"[XSS-Automation] {url}")
                for line in out_text.splitlines():
                    if re.search(r"vulnerable|payload", line, re.IGNORECASE):
                        report_lines.append(line.strip())
                report_lines.append("")
        else:
            warn("xss-automation not found, skipping.")

        sleep_for(2)

    with open(out.path("xssreport"), "a") as f:
        for line in report_lines:
            f.write(str(line) + "\n")

    ok(f"xssreport.txt updated, findings this run: {len([l for l in report_lines if l.startswith('[')])}")
