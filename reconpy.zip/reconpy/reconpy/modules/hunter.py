from reconpy.core.utils import log, ok, warn, tool_exists, run, read_lines, load_targets, to_url


def run_module(out, domain_input, subdomains_file=None, **kwargs):
    if not tool_exists("nuclei"):
        warn("hunter: nuclei not found, skipping module.")
        return

    subs = read_lines(subdomains_file) if subdomains_file else []
    domains = load_targets(domain_input)

    targets = sorted(set([to_url(s) for s in subs] + [to_url(d) for d in domains]))
    if not targets:
        warn("hunter: no targets available, skipping.")
        return

    ok(f"hunter: total targets: {len(targets)}")

    input_text = "\n".join(targets)
    log("hunter: running nuclei...")
    out_text = run(
        ["nuclei", "-silent", "-rate-limit", "5", "-c", "1", "-timeout", "10"],
        timeout=1800, input_text=input_text,
    )

    with open(out.path("report"), "a") as f:
        f.write("=" * 64 + "\n")
        f.write("NUCLEI (HUNTER) FINDINGS\n")
        f.write("=" * 64 + "\n")
        f.write(out_text + "\n")

    ok(f"hunter: findings appended to report.txt, lines: {len(out_text.splitlines())}")
