import re
from reconpy.core.utils import log, ok, warn, tool_exists, run, read_lines, sleep_for


def run_module(out, parameters_file=None, **kwargs):
    params_path = parameters_file or out.path("parameters")
    urls = read_lines(params_path)
    if not urls:
        warn("sqlrecon: no URLs found in parameters.txt, skipping.")
        return

    ok(f"sqlrecon: total URLs to test: {len(urls)}")

    report_lines = []

    for url in urls:
        log(f"sqlrecon: testing {url}...")

        if tool_exists("sqlmap"):
            out_text = run([
                "sqlmap", "-u", url, "--batch", "--level=1", "--risk=1",
                "--timeout=10", "--retries=1", "--technique=BEUST",
            ], timeout=300)
            if re.search(r"is vulnerable|parameter.*is vulnerable|injectable", out_text, re.IGNORECASE):
                report_lines.append(f"[SQLMap] {url}")
                for line in out_text.splitlines():
                    if re.search(r"vulnerable|injectable|parameter|payload|type:|title:", line, re.IGNORECASE):
                        report_lines.append(line.strip())
                report_lines.append("")
            sleep_for(5)
        else:
            warn("sqlmap not found, skipping sqlmap step.")

        if tool_exists("oralyzer"):
            out_text = run(["oralyzer"], timeout=60, input_text=url + "\n")
            if re.search(r"vulnerable|redirect", out_text, re.IGNORECASE):
                report_lines.append(f"[Oralyzer] {url}")
                report_lines.append(out_text.strip())
                report_lines.append("")
            sleep_for(3)
        else:
            warn("oralyzer not found, skipping.")

        if tool_exists("crlfuzz"):
            out_text = run(["crlfuzz", "-u", url, "-s"], timeout=60)
            if out_text.strip():
                report_lines.append(f"[CRLFuzz] {url}")
                report_lines.append(out_text.strip())
                report_lines.append("")
            sleep_for(3)
        else:
            warn("crlfuzz not found, skipping.")

    with open(out.path("sqlreport"), "a") as f:
        for line in report_lines:
            f.write(str(line) + "\n")

    ok(f"sqlreport.txt updated, findings this run: {len([l for l in report_lines if l.startswith('[')])}")
