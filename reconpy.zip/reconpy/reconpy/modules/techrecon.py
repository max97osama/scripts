import re
from reconpy.core.utils import log, ok, warn, tool_exists, run, read_lines, load_targets, sleep_for

PORT_TOOLS = {
    "21": ("FTP", "vsftpd / ProFTPD / FileZilla Server"),
    "22": ("SSH", "OpenSSH / Dropbear"),
    "23": ("Telnet", "Telnet daemon - CRITICAL: plaintext credentials"),
    "25": ("SMTP", "Postfix / Sendmail / Exim"),
    "53": ("DNS", "BIND / Unbound / PowerDNS / dnsmasq"),
    "67": ("DHCP", "ISC DHCP Server / dnsmasq"),
    "69": ("TFTP", "TFTP server - unauthenticated file transfer"),
    "80": ("HTTP", "Apache / Nginx / IIS / LiteSpeed / Caddy"),
    "110": ("POP3", "Dovecot / Courier / Cyrus"),
    "139": ("NetBIOS", "Samba / Windows File Sharing"),
    "143": ("IMAP", "Dovecot / Courier / Cyrus"),
    "161": ("SNMP", "Net-SNMP - CRITICAL: leaks OS, hardware, network info"),
    "443": ("HTTPS", "Apache / Nginx / IIS / LiteSpeed with SSL"),
    "445": ("SMB", "Samba / Windows SMB"),
    "465": ("SMTPS", "Postfix / Exim with SSL"),
    "587": ("SMTP Submission", "Postfix / Exim submission port"),
    "993": ("IMAPS", "Dovecot / Courier with SSL"),
    "995": ("POP3S", "Dovecot / Courier with SSL"),
    "1433": ("MSSQL", "Microsoft SQL Server"),
    "1521": ("Oracle DB", "Oracle Database"),
    "2049": ("NFS", "NFS server"),
    "2181": ("Zookeeper", "Apache Zookeeper"),
    "2375": ("Docker", "Docker daemon UNENCRYPTED - CRITICAL"),
    "2376": ("Docker TLS", "Docker daemon with TLS"),
    "2379": ("etcd", "etcd - Kubernetes control plane"),
    "3000": ("Dev Server", "Node.js / Grafana / React dev / Gitea"),
    "3306": ("MySQL", "MySQL / MariaDB"),
    "3389": ("RDP", "Windows Remote Desktop"),
    "4444": ("Metasploit / WildFly", "Metasploit listener or JBoss WildFly"),
    "4848": ("GlassFish", "GlassFish admin console"),
    "5432": ("PostgreSQL", "PostgreSQL database"),
    "5601": ("Kibana", "Kibana log visualization"),
    "5672": ("RabbitMQ", "RabbitMQ AMQP"),
    "5900": ("VNC", "VNC remote desktop"),
    "5984": ("CouchDB", "Apache CouchDB"),
    "6379": ("Redis", "Redis - CRITICAL: often unauthenticated RCE"),
    "6443": ("Kubernetes API", "Kubernetes API server"),
    "8000": ("Dev HTTP", "Django / Flask dev server"),
    "8080": ("Tomcat / Jenkins", "Apache Tomcat / Jenkins / Squid proxy"),
    "8086": ("InfluxDB", "InfluxDB time-series database"),
    "8443": ("Tomcat HTTPS", "Apache Tomcat HTTPS"),
    "8888": ("Jupyter", "Jupyter Notebook - CRITICAL"),
    "9000": ("SonarQube / Portainer", "SonarQube / Portainer / PHP-FPM"),
    "9090": ("Prometheus / Cockpit", "Prometheus metrics / Cockpit"),
    "9200": ("Elasticsearch", "Elasticsearch - CRITICAL"),
    "10250": ("Kubelet API", "Kubernetes Kubelet - CRITICAL"),
    "11211": ("Memcached", "Memcached - CRITICAL"),
    "15672": ("RabbitMQ UI", "RabbitMQ management web UI"),
    "27017": ("MongoDB", "MongoDB - CRITICAL"),
    "50000": ("Jenkins agent", "Jenkins agent port - CRITICAL"),
}
CRITICAL_PORTS = {"23", "2375", "6379", "8888", "9200", "10250", "11211", "27017", "50000", "161", "2379", "4444"}

NMAP_PORTS = ",".join(sorted(PORT_TOOLS.keys(), key=int))

VERSION_PAT = re.compile(r"(v?\d+\.\d+[\.\d]*|/\d+\.\d+[\.\d]*|\d+\.\d+[\.\d]*[a-zA-Z]\w*)", re.IGNORECASE)
SKIP_PAT = re.compile(
    r"^\s*$|^Starting Nmap|^Host is up|Nmap done|^#|^SF:|latency|Not shown|^PORT\s+STATE"
    r"|Warning:|^Initiating|^Completed|^NSE:|^Scanning|^Sending|^Increasing|^Stats:|^Read data",
    re.IGNORECASE,
)
TECH_KEYWORDS = re.compile(
    r"apache|nginx|iis|litespeed|caddy|tomcat|php|python|ruby|java|node|perl|asp\.net|golang|rust"
    r"|wordpress|drupal|joomla|magento|prestashop|typo3|opencart|concrete5|ghost|october|craft|umbraco"
    r"|laravel|django|flask|rails|spring|express|symfony|codeigniter"
    r"|mysql|mariadb|postgresql|mssql|oracle|mongodb|redis|elasticsearch|cassandra|sqlite|couchdb|memcached"
    r"|react|angular|vue|jquery|bootstrap|svelte|ubuntu|debian|centos|redhat|fedora|windows server|freebsd"
    r"|openssl|openssh|mod_ssl|cloudflare|akamai|fastly|varnish|squid|haproxy"
    r"|docker|kubernetes|jenkins|gitlab|jira|confluence|grafana|kibana|prometheus|zookeeper|kafka|rabbitmq"
    r"|x-powered-by|server:|x-generator|cpanel|plesk|glassfish|wildfly|jetty|waf|firewall"
    r"|plugin|theme|version|banner|product|service|vulnerability|CVE-",
    re.IGNORECASE,
)
OPEN_PAT = re.compile(r"(\d+)/tcp\s+(open|filtered|open\|filtered)", re.IGNORECASE)


def run_module(out, subdomains_file=None, ips_file=None, **kwargs):
    subs_path = subdomains_file or out.path("subdomains")
    ips_path = ips_file or out.path("ips")

    subs = read_lines(subs_path)
    ips = read_lines(ips_path)

    targets = sorted(set(subs) | set(ips))
    if not targets:
        warn("techrecon: no subdomains or IPs found, skipping.")
        return

    http_targets = []
    for t in targets:
        if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", t):
            continue
        http_targets.append(t if t.startswith("http") else f"https://{t}")

    ok(f"techrecon: total targets: {len(targets)}")

    raw_sections = []
    port_findings = {}

    for target in targets:
        if tool_exists_local("nmap"):
            log(f"techrecon: nmap scanning {target}...")
            out_text = run([
                "nmap", "-sV", "-sC", "-T2", "-p", NMAP_PORTS,
                "--min-rate", "100", "--max-rate", "200",
                "--script", "banner,http-server-header,http-generator,http-title,http-auth-finder,"
                            "http-headers,ssh-hostkey,ftp-anon,ssl-cert,http-robots.txt,snmp-info,"
                            "smb-os-discovery,redis-info,mongodb-info,mysql-info,ms-sql-info",
                target,
            ], timeout=600)
            raw_sections.append((f"=== NMAP: {target} ===", out_text))

            port_hits = []
            for port, state in OPEN_PAT.findall(out_text):
                if port in PORT_TOOLS:
                    service, tools = PORT_TOOLS[port]
                    flag = " *** CRITICAL ***" if port in CRITICAL_PORTS else ""
                    entry = f"  PORT {port} ({state.upper()}): {service} -> Possibly: {tools}{flag}"
                    if entry not in port_hits:
                        port_hits.append(entry)
            if port_hits:
                port_findings[target] = port_hits
            sleep_for(3)

    detected_wordpress = []
    detected_other_cms = []

    for target in http_targets:
        if tool_exists_local("whatweb"):
            log(f"techrecon: whatweb on {target}...")
            out_text = run(["whatweb", target, "--color=never", "-a", "1"], timeout=60)
            raw_sections.append((f"=== WHATWEB: {target} ===", out_text))
            if "wordpress" in out_text.lower():
                detected_wordpress.append(target)
            sleep_for(3)

        if tool_exists_local("webanalyze"):
            log(f"techrecon: webanalyze on {target}...")
            out_text = run(["webanalyze", "-host", target, "-crawl", "1"], timeout=60)
            raw_sections.append((f"=== WEBANALYZE: {target} ===", out_text))
            sleep_for(3)

        out_text = run(["curl", "-skI", target, "--max-time", "10", "-A", "Mozilla/5.0"], timeout=15)
        raw_sections.append((f"=== CURL HEADERS: {target} ===", out_text))

        if tool_exists_local("wafw00f"):
            log(f"techrecon: wafw00f on {target}...")
            out_text = run(["wafw00f", target], timeout=60)
            raw_sections.append((f"=== WAFW00F: {target} ===", out_text))
            sleep_for(3)

        if tool_exists_local("httpx"):
            log(f"techrecon: httpx tech-detect on {target}...")
            out_text = run(
                ["httpx", "-tech-detect", "-status-code", "-title", "-server", "-silent", "-t", "1", "-timeout", "10"],
                timeout=30, input_text=target + "\n",
            )
            raw_sections.append((f"=== HTTPX TECH: {target} ===", out_text))
            sleep_for(3)

        if tool_exists_local("cmseek"):
            log(f"techrecon: cmseek on {target}...")
            out_text = run(["cmseek", "-u", target, "--follow-redirect", "-r"], timeout=90)
            raw_sections.append((f"=== CMSEEK: {target} ===", out_text))
            low = out_text.lower()
            if "wordpress" in low and target not in detected_wordpress:
                detected_wordpress.append(target)
            else:
                for cms in ["drupal", "joomla", "magento", "prestashop", "typo3", "opencart",
                            "concrete5", "ghost", "october", "craft", "umbraco", "moodle",
                            "vbulletin", "phpbb", "xenforo", "modx", "silverstripe"]:
                    if cms in low:
                        detected_other_cms.append((target, cms))
                        break
            sleep_for(3)

    for target in detected_wordpress:
        if tool_exists_local("wpscan"):
            log(f"techrecon: WordPress detected on {target}, running wpscan...")
            out_text = run([
                "wpscan", "--url", target, "--no-banner", "--disable-tls-checks",
                "--throttle", "2000", "--request-timeout", "10",
                "--enumerate", "vp,vt,u,tt,cb,dbe",
            ], timeout=300)
            raw_sections.append((f"=== WPSCAN: {target} ===", out_text))
            sleep_for(10)

    for target, cms_name in detected_other_cms:
        if tool_exists_local("cmsmap"):
            log(f"techrecon: {cms_name} detected on {target}, running cmsmap...")
            out_text = run(["cmsmap", target, "-t", "1"], timeout=300)
            raw_sections.append((f"=== CMSMAP ({cms_name}): {target} ===", out_text))
            sleep_for(10)

    tech_lines = []
    seen = set()

    if port_findings:
        tech_lines.append("=" * 60)
        tech_lines.append("PORT-BASED TOOL DETECTION")
        tech_lines.append("=" * 60)
        for target, entries in port_findings.items():
            tech_lines.append(f"\nTarget: {target}")
            tech_lines.append("-" * 40)
            tech_lines.extend(entries)

    for header, text in raw_sections:
        section_lines = []
        for line in text.splitlines():
            line_s = line.strip()
            if SKIP_PAT.search(line_s):
                continue
            if not VERSION_PAT.search(line_s) and not TECH_KEYWORDS.search(line_s):
                continue
            if line_s in seen:
                continue
            seen.add(line_s)
            section_lines.append(line_s)
        if section_lines:
            tech_lines.append(f"\n{header}")
            tech_lines.append("-" * len(header))
            tech_lines.extend(section_lines)

    with open(out.path("tech"), "a") as f:
        for line in tech_lines:
            f.write(line + "\n")

    ok(f"tech.txt total lines written this run: {len(tech_lines)}")


def tool_exists_local(name):
    return tool_exists(name)
