import os

DEFAULT_WORDLISTS = {
    "subs": "/root/wordlist/shorts/subdomains.txt",
    "kite": "/root/wordlist/large.kite",
    "dir": "/root/wordlist/shorts/dir.txt",
    "xss": "/root/wordlist/shorts/xss.txt",
}

OUTPUT_FILES = {
    "subdomains": "subdomains.txt",
    "activesubs": "activesubs.txt",
    "subs": "subs.txt",
    "cleanedsubs": "cleanedsubs.txt",
    "validsubs": "validsubs.txt",
    "ips": "ips.txt",
    "ipsv6": "ipsv6.txt",
    "urls": "urls.txt",
    "curls": "curls.txt",
    "findurls": "findurls.txt",
    "burl": "burl.txt",
    "parameters": "parameters.txt",
    "js": "js.txt",
    "alljs": "alljs.txt",
    "tech": "tech.txt",
    "vulnerable_urls": "vulnerable_urls.txt",
    "report": "report.txt",
    "nmapreport": "nmapreport.txt",
    "xssreport": "xssreport.txt",
    "sqlreport": "sqlreport.txt",
    "commixreport": "cmdireport.txt",
    "smugglerreport": "smugglerreport.txt",
    "secretsreport": "secretsreport.txt",
    "karmareport": "karmareport.txt",
    "findings": "Findings.txt",
}


def haktrails_is_configured():
    config_path = os.path.expanduser("~/.config/haktrails/config.yml")
    if not os.path.isfile(config_path):
        return False
    with open(config_path, "r") as f:
        content = f.read()
    return "securitytrails-key" in content and len(content.strip()) > len("securitytrails-key:")


def setup_haktrails_from_env():
    """
    Writes ~/.config/haktrails/config.yml only if SECURITYTRAILS_API_KEY is set
    in the environment and the config file doesn't already exist. Never hardcodes
    a key. Set your key once with:
        export SECURITYTRAILS_API_KEY="your-key-here"
    or configure haktrails yourself beforehand; this function then does nothing.
    """
    if haktrails_is_configured():
        return True

    api_key = os.environ.get("SECURITYTRAILS_API_KEY")
    if not api_key:
        return False

    config_dir = os.path.expanduser("~/.config/haktrails")
    os.makedirs(config_dir, exist_ok=True)
    config_path = os.path.join(config_dir, "config.yml")
    with open(config_path, "w") as f:
        f.write(f"securitytrails-key: {api_key}\n")
    return True
