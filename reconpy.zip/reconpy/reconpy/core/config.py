import os

SECURITYTRAILS_API_KEY = "DnZMyYFsI0cUX982ptBsakjRdRKJdr2z"

DEFAULT_WORDLISTS = {
    "subs": "/root/wordlist/shorts/subdomains.txt",
    "kite": "/root/wordlist/large.kite",
    "dir": "/root/wordlist/shorts/dir.txt",
    "xss": "/root/wordlist/shorts/xss.txt",
}

OUTPUT_FILES = {
    "subdomains": "subdomains.txt",
    "activesubs": "activesubs.txt",
    "subs": "subs.txt",
    "cleanedsubs": "cleanedsubs.txt",
    "validsubs": "validsubs.txt",
    "ips": "ips.txt",
    "ipsv6": "ipsv6.txt",
    "urls": "urls.txt",
    "curls": "curls.txt",
    "findurls": "findurls.txt",
    "burl": "burl.txt",
    "parameters": "parameters.txt",
    "js": "js.txt",
    "alljs": "alljs.txt",
    "tech": "tech.txt",
    "vulnerable_urls": "vulnerable_urls.txt",
    "report": "report.txt",
    "nmapreport": "nmapreport.txt",
    "xssreport": "xssreport.txt",
    "sqlreport": "sqlreport.txt",
    "commixreport": "cmdireport.txt",
    "smugglerreport": "smugglerreport.txt",
    "secretsreport": "secretsreport.txt",
    "karmareport": "karmareport.txt",
    "findings": "Findings.txt",
}


def setup_haktrails():
    config_dir = os.path.expanduser("~/.config/haktrails")
    os.makedirs(config_dir, exist_ok=True)
    config_path = os.path.join(config_dir, "config.yml")
    with open(config_path, "w") as f:
        f.write(f"securitytrails-key: {SECURITYTRAILS_API_KEY}\n")
