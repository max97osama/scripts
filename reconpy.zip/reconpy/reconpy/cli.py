import argparse
import sys
import os

from reconpy.core.utils import OutputFiles, log, ok, warn, wordlist_or_none
from reconpy.core.config import DEFAULT_WORDLISTS
from reconpy.modules import (
    passivesubrecon, brutesubrecon, iprecon, techrecon, nmapscan,
    dirrecon, crawlrecon, urlrecon, findrecon, apirecon, hunter,
    urlfilter, cleanurls, xssrecon, sqlrecon, commixrecon, smugglerrecon,
)

MODULE_MAP = {
    "passivesubrecon": passivesubrecon,
    "brutesubrecon": brutesubrecon,
    "iprecon": iprecon,
    "techrecon": techrecon,
    "nmapscan": nmapscan,
    "dirrecon": dirrecon,
    "crawlrecon": crawlrecon,
    "urlrecon": urlrecon,
    "findrecon": findrecon,
    "apirecon": apirecon,
    "hunter": hunter,
    "urlfilter": urlfilter,
    "cleanurls": cleanurls,
    "xssrecon": xssrecon,
    "sqlrecon": sqlrecon,
    "commixrecon": commixrecon,
    "smugglerrecon": smugglerrecon,
}

FULL_ORDER = [
    "passivesubrecon",
    "brutesubrecon",
    "iprecon",
    "techrecon",
    "nmapscan",
    "urlrecon",
    "dirrecon",
    "crawlrecon",
    "findrecon",
    "apirecon",
    "cleanurls",
    "urlfilter",
    "hunter",
    "xssrecon",
    "sqlrecon",
    "commixrecon",
    "smugglerrecon",
]


def resolve_wordlist(cli_value, default_key):
    candidate = cli_value or DEFAULT_WORDLISTS.get(default_key)
    resolved = wordlist_or_none(candidate)
    if candidate and not resolved:
        warn(f"wordlist '{candidate}' not found or empty, continuing without it.")
    return resolved


def build_parser():
    parser = argparse.ArgumentParser(
        prog="reconpy",
        description="Python recon orchestrator - full pipeline or single module execution.",
    )
    parser.add_argument("domain", help="Target domain or path to a text file with a list of domains.")
    parser.add_argument(
        "-m", "--module",
        choices=list(MODULE_MAP.keys()) + ["full"],
        default="full",
        help="Which module to run. Default: full (runs the entire pipeline in order).",
    )
    parser.add_argument(
        "-o", "--output-dir",
        default=None,
        help="Directory where all output text files are written. Default: current working directory.",
    )
    parser.add_argument("--subdomains", help="Path to an existing subdomains.txt file to use/update.")
    parser.add_argument("--subs-wordlist", help="Wordlist for active subdomain bruteforce.")
    parser.add_argument("--kite-wordlist", help="Kiterunner .kite wordlist for API recon.")
    parser.add_argument("--dir-wordlist", help="Wordlist for directory bruteforce and crawling.")
    parser.add_argument("--xss-wordlist", help="Custom XSS payload list.")
    parser.add_argument("--depth", type=int, default=3, help="Crawl depth for crawlrecon module. Default: 3.")
    parser.add_argument("--parameters-file", help="Path to parameters.txt for xss/sql/commix modules.")
    parser.add_argument("--ips-file", help="Path to ips.txt for techrecon/nmapscan modules.")
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    output_dir = args.output_dir or os.getcwd()
    out = OutputFiles(output_dir)
    log(f"Output directory: {os.path.abspath(output_dir)}")

    subs_wordlist = resolve_wordlist(args.subs_wordlist, "subs")
    kite_wordlist = resolve_wordlist(args.kite_wordlist, "kite")
    dir_wordlist = resolve_wordlist(args.dir_wordlist, "dir")
    xss_wordlist = resolve_wordlist(args.xss_wordlist, "xss")

    subdomains_file = args.subdomains or out.path("subdomains")
    parameters_file = args.parameters_file or out.path("parameters")
    ips_file = args.ips_file or out.path("ips")

    common_kwargs = dict(
        domain_input=args.domain,
        subdomains_file=subdomains_file,
        subs_wordlist=subs_wordlist,
        kite_wordlist=kite_wordlist,
        dir_wordlist=dir_wordlist,
        xss_wordlist=xss_wordlist,
        parameters_file=parameters_file,
        ips_file=ips_file,
        depth=args.depth,
    )

    if args.module != "full":
        module = MODULE_MAP[args.module]
        log(f"Running single module: {args.module}")
        module.run_module(out, **common_kwargs)
        ok(f"Module {args.module} complete.")
        return

    log("Running full recon pipeline.")
    for name in FULL_ORDER:
        module = MODULE_MAP[name]
        print()
        print("=" * 60)
        print(f"  STEP: {name.upper()}")
        print("=" * 60)
        try:
            module.run_module(out, **common_kwargs)
        except Exception as e:
            warn(f"{name} raised an exception and was skipped: {e}")

    print()
    print("=" * 60)
    print("  FULL RECON COMPLETE")
    print("=" * 60)
    print()
    print("[+] Output files summary:")

    from reconpy.core.config import OUTPUT_FILES
    for key, filename in OUTPUT_FILES.items():
        path = os.path.join(out.base_dir, filename)
        if os.path.isfile(path) and os.path.getsize(path) > 0:
            with open(path, "r", errors="ignore") as f:
                count = sum(1 for _ in f)
            print(f"    {filename} — {count} lines")


if __name__ == "__main__":
    main()
