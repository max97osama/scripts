# reconpy

Python recon orchestrator for bug bounty workflows. Wraps ffuf, amass, subfinder,
sublist3r, haktrails, dnsx, httpx, nmap, whatweb, webanalyze, wpscan, cmsmap,
dirsearch, gobuster, hakrawler, katana, gospider, gau, waybackurls, paramspider,
assetfinder, linkfinder, secretfinder, xnLinkFinder, urlfinder, mantra, karma_v2,
smap, kiterunner, arjun, qsreplace, oralyzer, openredirex, nuclei, dalfox, xsstrike,
loxs, pwnxss, xspear, xssfinder, sqlmap, crlfuzz, commix, and smuggler into one
Python CLI, `reconpy`, that can be installed once and run globally from any directory.

## Install

Requires Python 3.8+. From inside the extracted project folder:

```bash
pip install --break-system-packages .
```

This installs the `reconpy` package and creates a global `reconpy` command on your
PATH (typically at `~/.local/bin/reconpy` on Debian — make sure that's in your PATH:
`export PATH="$HOME/.local/bin:$PATH"` in your `.bashrc` if it isn't already).

To upgrade after making changes to the source:

```bash
pip install --break-system-packages --force-reinstall .
```

To uninstall:

```bash
pip uninstall reconpy
```

## Usage

Run it from any directory — output text files are written into whatever directory
you're standing in when you run the command (or `-o` if you specify one):

```bash
cd ~/recon/chmedia
reconpy chmedia.ch
```

This runs the entire pipeline in order and drops every result file
(`subdomains.txt`, `ips.txt`, `urls.txt`, `parameters.txt`, `tech.txt`,
`nmapreport.txt`, `xssreport.txt`, `sqlreport.txt`, etc.) flat in
`~/recon/chmedia`, no subdirectories.

### Full pipeline with wordlists

```bash
reconpy chmedia.ch \
    --subs-wordlist /root/wordlist/shorts/subdomains.txt \
    --kite-wordlist /root/wordlist/large.kite \
    --dir-wordlist /root/wordlist/shorts/dir.txt \
    --xss-wordlist /root/wordlist/shorts/xss.txt
```

Any wordlist path that doesn't exist or is empty is silently skipped — that specific
step just runs without it (or is skipped entirely if it strictly requires one, like
`brutesubrecon` needing a subdomains wordlist, or `apirecon` needing a `.kite` file).

### Domain list instead of a single domain

```bash
reconpy domains.txt
```

Works anywhere a single domain works — every module accepts either.

### Run a single module instead of the full pipeline

```bash
reconpy chmedia.ch -m passivesubrecon
reconpy chmedia.ch -m iprecon
reconpy chmedia.ch -m techrecon
reconpy chmedia.ch -m xssrecon
```

Full list of available modules:

```
passivesubrecon  brutesubrecon  iprecon  techrecon  nmapscan
dirrecon  crawlrecon  urlrecon  findrecon  apirecon  hunter
urlfilter  cleanurls  xssrecon  sqlrecon  commixrecon  smugglerrecon
```

### Explicit output directory

```bash
reconpy chmedia.ch -o /root/recon/chmedia
```

### SecurityTrails / haktrails setup (optional)

No API key is hardcoded anywhere in this project. If you want `haktrails` to run
during `passivesubrecon`, either:

**Option A** — set an environment variable once, and reconpy will write the
haktrails config file for you automatically on first run:

```bash
export SECURITYTRAILS_API_KEY="your-key-here"
```

Add that line to `~/.bashrc` to persist it across sessions.

**Option B** — configure haktrails yourself ahead of time exactly as you already
have:

```bash
mkdir -p ~/.config/haktrails
echo "securitytrails-key: your-key-here" > ~/.config/haktrails/config.yml
```

If neither is set, `passivesubrecon` simply skips the haktrails step and continues
with amass/subfinder/sublist3r.

## Notes on tool redundancy

To keep runs fast on a 1-core/1GB VM, each external tool is only called from one
place in the pipeline:

- `dnsx` / `httpx` resolution — only in `iprecon` (discovery-only modules like
  `brutesubrecon` no longer duplicate this work)
- `linkfinder` / `secretfinder` / `assetfinder` — only in `findrecon`
- `paramspider` — only in `urlrecon`
- `crlfuzz` — only in `sqlrecon`
- `oralyzer` — only in `apirecon`

`brutesubrecon`'s `ffuf` call is capped with `-maxtime 1800` (30 minutes per domain)
so a large wordlist can never hang indefinitely — it now also prints an estimated
runtime before starting so you can judge if a wordlist is too big for the target.

## Output files

All files are flat text files in the output directory, no subdirectories:

```
subdomains.txt      activesubs.txt      subs.txt          cleanedsubs.txt
validsubs.txt       ips.txt             ipsv6.txt         urls.txt
curls.txt           findurls.txt        burl.txt          parameters.txt
js.txt              alljs.txt           tech.txt          vulnerable_urls.txt
report.txt          nmapreport.txt      xssreport.txt     sqlreport.txt
cmdireport.txt       smugglerreport.txt  secretsreport.txt karmareport.txt
Findings.txt
```
